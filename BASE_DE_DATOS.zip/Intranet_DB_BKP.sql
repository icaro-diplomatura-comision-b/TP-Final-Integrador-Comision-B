CREATE DATABASE  IF NOT EXISTS `intranet` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `intranet`;
-- MySQL dump 10.13  Distrib 8.0.11, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: intranet
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ciudad`
--

DROP TABLE IF EXISTS `ciudad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `ciudad` (
  `IdCiudad` int NOT NULL AUTO_INCREMENT,
  `Descripcion` varchar(100) DEFAULT NULL,
  `IdPais` int DEFAULT NULL,
  PRIMARY KEY (`IdCiudad`),
  KEY `IdPais_idx` (`IdPais`),
  CONSTRAINT `IdPais_Ciudad` FOREIGN KEY (`IdPais`) REFERENCES `pais` (`IdPais`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ciudad`
--

LOCK TABLES `ciudad` WRITE;
/*!40000 ALTER TABLE `ciudad` DISABLE KEYS */;
INSERT INTO `ciudad` (`IdCiudad`, `Descripcion`, `IdPais`) VALUES (1,'Cordoba',1),(2,'Buenos Aires',1),(3,'Tucuman',1),(4,'Rio Negro',1),(5,'Salta',1),(6,'Jujuy',1),(7,'Misiones',1);
/*!40000 ALTER TABLE `ciudad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estadomensaje`
--

DROP TABLE IF EXISTS `estadomensaje`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `estadomensaje` (
  `IdEstadoMensaje` int NOT NULL AUTO_INCREMENT,
  `Descipcion` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`IdEstadoMensaje`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estadomensaje`
--

LOCK TABLES `estadomensaje` WRITE;
/*!40000 ALTER TABLE `estadomensaje` DISABLE KEYS */;
INSERT INTO `estadomensaje` (`IdEstadoMensaje`, `Descipcion`) VALUES (1,'Enviado');
/*!40000 ALTER TABLE `estadomensaje` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mensajes`
--

DROP TABLE IF EXISTS `mensajes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `mensajes` (
  `IdMensajes` int NOT NULL AUTO_INCREMENT,
  `IdRemitente` int DEFAULT NULL,
  `IdDestinatario` int DEFAULT NULL,
  `Fecha` datetime DEFAULT NULL,
  `Mensaje` varchar(144) DEFAULT NULL,
  `IdEstadoMensaje` int DEFAULT NULL,
  `MensajeLeido` int DEFAULT NULL,
  PRIMARY KEY (`IdMensajes`),
  KEY `IdRemitente_idx` (`IdRemitente`),
  KEY `IdDestinatarios_idx` (`IdDestinatario`),
  KEY `IdEstadoMensaje_idx` (`IdEstadoMensaje`),
  CONSTRAINT `IdDestinatarios` FOREIGN KEY (`IdDestinatario`) REFERENCES `usuarios` (`IdUsuarios`),
  CONSTRAINT `IdEstadoMensaje` FOREIGN KEY (`IdEstadoMensaje`) REFERENCES `estadomensaje` (`IdEstadoMensaje`),
  CONSTRAINT `IdRemitente` FOREIGN KEY (`IdRemitente`) REFERENCES `usuarios` (`IdUsuarios`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mensajes`
--

LOCK TABLES `mensajes` WRITE;
/*!40000 ALTER TABLE `mensajes` DISABLE KEYS */;
INSERT INTO `mensajes` (`IdMensajes`, `IdRemitente`, `IdDestinatario`, `Fecha`, `Mensaje`, `IdEstadoMensaje`, `MensajeLeido`) VALUES (1,1,2,'2022-01-26 00:00:00','Hola Juan Carlos',1,0),(2,1,3,'2022-01-26 00:00:00','Hola Juan Carlos',1,0),(3,1,4,'2022-01-26 00:00:00','Hola Juan Carlos',1,0),(4,2,5,'2022-01-26 00:00:00','Tengo hambre',1,0),(5,5,1,'2022-01-26 00:00:00','Hoy cumple mi mama',1,0),(6,3,7,'2022-01-26 00:00:00','Quien Sos?',1,0),(7,7,3,'2022-01-26 00:00:00','Luck Soy Tu Padre!',1,0);
/*!40000 ALTER TABLE `mensajes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pais`
--

DROP TABLE IF EXISTS `pais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `pais` (
  `IdPais` int NOT NULL AUTO_INCREMENT,
  `Descripcion` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`IdPais`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pais`
--

LOCK TABLES `pais` WRITE;
/*!40000 ALTER TABLE `pais` DISABLE KEYS */;
INSERT INTO `pais` (`IdPais`, `Descripcion`) VALUES (1,'Argentina'),(2,'Brasil'),(3,'Mexico'),(4,'Estados Unidos'),(5,'Bolivia'),(6,'Colombia');
/*!40000 ALTER TABLE `pais` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `usuarios` (
  `IdUsuarios` int NOT NULL AUTO_INCREMENT,
  `Apeliido` varchar(150) DEFAULT NULL,
  `Nombre` varchar(150) DEFAULT NULL,
  `Usuario` varchar(150) DEFAULT NULL,
  `Contraseña` varchar(150) DEFAULT NULL,
  `IdPais` int DEFAULT NULL,
  `IdCiudad` int DEFAULT NULL,
  PRIMARY KEY (`IdUsuarios`),
  KEY `IdPais_idx` (`IdPais`),
  KEY `IdCiudad_idx` (`IdCiudad`),
  CONSTRAINT `IdCiudad_Usuarios` FOREIGN KEY (`IdCiudad`) REFERENCES `ciudad` (`IdCiudad`),
  CONSTRAINT `IdPais_Usuarios` FOREIGN KEY (`IdPais`) REFERENCES `pais` (`IdPais`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` (`IdUsuarios`, `Apeliido`, `Nombre`, `Usuario`, `Contraseña`, `IdPais`, `IdCiudad`) VALUES (1,'Carabajal','Leonardo','Calej22','Pepe258',1,1),(2,'Jaime','Larisa','Ottito','Laru2022',1,2),(3,'Perez','Nicolas','Raton','Dientes365',1,3),(4,'Pereyra','Luciano','River22','Luciano2022',1,1),(5,'Maldonado','Ezequiel','Laucha','Laucha2022',1,2),(6,'Mamondi','Maria','Mimi','Mimi2022',1,3),(7,'Alvarez','Micaela','Miku','Miku2022',1,1),(8,'Mena','Agustina','Gugu','Gugu2022',1,4),(9,'Basquez','Lautaro','Lauti','Lauti2022',1,1),(10,'Nardon','Pablo','Pablincho','Pablo2022',1,4);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-26 14:18:59
