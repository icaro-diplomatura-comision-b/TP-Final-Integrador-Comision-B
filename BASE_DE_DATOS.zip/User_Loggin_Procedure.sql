/*Procedimiento para inicio de Session, devuelve 1 si encuetra al usuario y contraseña, de lo contrario devuelve 0*/
DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `User_Login`(IN usuario_in VARCHAR(150), IN contraseña_in VARCHAR(150), OUT existe INT)
BEGIN

SELECT CASE WHEN EXISTS (
SELECT * FROM intranet.usuarios
WHERE Usuario=usuario_in
AND Contraseña=contraseña_in) THEN 1 ELSE 0 END AS existe;

END$$
DELIMITER ;

/*Para Ejecutar*/
/*
SET @usuario='Calej22', @contrasena='Pepe258';
CALL `intranet`.`User_Login`(@usuario, @contrasena,@flag_existe);
*/