-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema Intranet
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema Intranet
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `Intranet` DEFAULT CHARACTER SET utf8 ;
USE `Intranet` ;

-- -----------------------------------------------------
-- Table `Intranet`.`Pais`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Intranet`.`Pais` (
  `IdPais` INT NOT NULL AUTO_INCREMENT,
  `Descripcion` VARCHAR(150) NULL,
  PRIMARY KEY (`IdPais`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Intranet`.`Ciudad`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Intranet`.`Ciudad` (
  `IdCiudad` INT NOT NULL AUTO_INCREMENT,
  `Descripcion` VARCHAR(100) NULL,
  `IdPais` INT NULL,
  PRIMARY KEY (`IdCiudad`),
  INDEX `IdPais_idx` (`IdPais` ASC) VISIBLE,
  CONSTRAINT `IdPais_Ciudad`
    FOREIGN KEY (`IdPais`)
    REFERENCES `Intranet`.`Pais` (`IdPais`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Intranet`.`Usuarios`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Intranet`.`Usuarios` (
  `IdUsuarios` INT NOT NULL AUTO_INCREMENT,
  `Apeliido` VARCHAR(150) NULL,
  `Nombre` VARCHAR(150) NULL,
  `Usuario` VARCHAR(150) NULL,
  `Contraseña` VARCHAR(150) NULL,
  `IdPais` INT NULL,
  `IdCiudad` INT NULL,
  PRIMARY KEY (`IdUsuarios`),
  INDEX `IdPais_idx` (`IdPais` ASC) VISIBLE,
  INDEX `IdCiudad_idx` (`IdCiudad` ASC) VISIBLE,
  CONSTRAINT `IdPais_Usuarios`
    FOREIGN KEY (`IdPais`)
    REFERENCES `Intranet`.`Pais` (`IdPais`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `IdCiudad_Usuarios`
    FOREIGN KEY (`IdCiudad`)
    REFERENCES `Intranet`.`Ciudad` (`IdCiudad`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Intranet`.`EstadoMensaje`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Intranet`.`EstadoMensaje` (
  `IdEstadoMensaje` INT NOT NULL AUTO_INCREMENT,
  `Descipcion` VARCHAR(150) NULL,
  PRIMARY KEY (`IdEstadoMensaje`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Intranet`.`Mensajes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Intranet`.`Mensajes` (
  `IdMensajes` INT NOT NULL AUTO_INCREMENT,
  `IdRemitente` INT NULL,
  `IdDestinatario` INT NULL,
  `Fecha` DATETIME NULL,
  `Mensaje` VARCHAR(144) NULL,
  `IdEstadoMensaje` INT NULL,
  `MensajeLeido` INT NULL,
  PRIMARY KEY (`IdMensajes`),
  INDEX `IdRemitente_idx` (`IdRemitente` ASC) VISIBLE,
  INDEX `IdDestinatarios_idx` (`IdDestinatario` ASC) VISIBLE,
  INDEX `IdEstadoMensaje_idx` (`IdEstadoMensaje` ASC) VISIBLE,
  CONSTRAINT `IdRemitente`
    FOREIGN KEY (`IdRemitente`)
    REFERENCES `Intranet`.`Usuarios` (`IdUsuarios`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `IdDestinatarios`
    FOREIGN KEY (`IdDestinatario`)
    REFERENCES `Intranet`.`Usuarios` (`IdUsuarios`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `IdEstadoMensaje`
    FOREIGN KEY (`IdEstadoMensaje`)
    REFERENCES `Intranet`.`EstadoMensaje` (`IdEstadoMensaje`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
