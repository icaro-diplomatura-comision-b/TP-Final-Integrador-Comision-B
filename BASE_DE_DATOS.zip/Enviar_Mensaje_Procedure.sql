CREATE DEFINER=`root`@`localhost` PROCEDURE `Enviar_Mensaje`(	IN IdRemitente_IN VARCHAR(150),
									IN Destinatarios_IN VARCHAR(150),
									IN Fecha_IN VARCHAR(150),
									IN Mensaje_IN VARCHAR(150))
BEGIN
/*CREO TABLA TEMPORAL PARA LLENAR CON LOS DATOS DE LOS DESTINATARIOS*/
CREATE TEMPORARY TABLE IF NOT EXISTS intranet.Destinatarios_Temp(
   IdDestinatarios int
);
TRUNCATE TABLE intranet.Destinatarios_Temp;

SET @dest= Destinatarios_IN;
SET	@consulta_destinatarios=(SELECT CONCAT('INSERT INTO intranet.Destinatarios_Temp (IdDestinatarios) VALUES ','(',REPLACE(@dest,',','),('),')'));

PREPARE stmt FROM @consulta_destinatarios;
execute stmt;

/*FIN PARTE 1*/

/*SETEAMOS LAS VARIABLES QUE RESTAN PARA REALIZAR EL INSERT FINAL DE LOS MENSAJES*/
SET @remitente=IdRemitente_IN;
SET @fecha=Fecha_IN;
SET @mensaje=Mensaje_IN;
    
SET @consulta_final_insert=(SELECT CONCAT('INSERT INTO intranet.mensajes(IdRemitente,IdDestinatario,Fecha,Mensaje,IdEstadoMensaje,MensajeLeido)VALUES',GROUP_CONCAT(Valores)) as INSERT_FINAL
FROM ( 
SELECT CONCAT('(',@remitente,',', D.IdUsuarios,',"', @fecha,'",','"',@mensaje,'"',',', 1,',', 0,')') as Valores
FROM intranet.usuarios R RIGHT JOIN (SELECT IdUsuarios from intranet.usuarios 
WHERE IdUsuarios IN (SELECT * FROM  intranet.Destinatarios_Temp)) D ON R.IdUsuarios=D.IdUsuarios
) AS FINAL);

PREPARE stmt FROM @consulta_final_insert;
execute stmt;

/*FIN PARTE 2*/

END

/*Para Ejecutar*/

/*
SET @destinatario= '7,4';
SET @remitente='3';
SET @fecha='2022-01-27';
SET @mensaje='BIENVENIDOS A LA CRIPTA';

CALL `intranet`.`Enviar_Mensaje`(@remitente, @destinatario, @fecha, @mensaje);
*/