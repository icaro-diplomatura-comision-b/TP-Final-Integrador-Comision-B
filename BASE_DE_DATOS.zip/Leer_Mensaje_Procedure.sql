/*Recibe por parametro el ID de mensaje que se leyo y realiza un UPDATE sobre la tabla sobre el campo MensajeLeido y lo setea en 1*/
CREATE PROCEDURE `Leer_Mensaje`(IN IdMensaje INT)
BEGIN

SET @Mensaje=IdMensaje;

UPDATE intranet.mensajes
SET MensajeLeido=1
WHERE IdMensajes=@Mensaje;

END


/*Para Ejecutar*/
/*
SET @mensaje=3;

CALL `intranet`.`Leer_Mensaje`(@mensaje);
*/