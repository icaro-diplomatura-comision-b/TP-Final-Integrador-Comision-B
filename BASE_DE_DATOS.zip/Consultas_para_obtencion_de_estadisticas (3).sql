/*Cantidad Mensajes Enviados*/
SELECT r.Usuario as Remitente, count(d.Usuario) Cantidad_Mensajes_Enviados
FROM intranet.mensajes m LEFT JOIN intranet.usuarios r ON m.IdRemitente=r.IdUsuarios
						 LEFT JOIN intranet.usuarios d ON m.IdDestinatario=d.IdUsuarios
GROUP BY Remitente;
                      
					  
/*Cantidad Mensajes Enviados por Remitente/ Destinatarios */
SET @Remitente=1;
SET @Destinatario=2;

SELECT r.Usuario as Remitente,d.Usuario as Destinatario, count(d.Usuario) Cantidad_Mensajes_Enviados
FROM intranet.mensajes m LEFT JOIN intranet.usuarios r ON m.IdRemitente=r.IdUsuarios
						 LEFT JOIN intranet.usuarios d ON m.IdDestinatario=d.IdUsuarios
WHERE m.IdRemitente=@Remitente  /*Este Valor se modifica para filtrar diferentes usuarios Remitentes*/
AND m.IdDestinatario=@Destinatario /*Este Valor se modifica para filtrar diferentes usuarios Destinatarios*/
GROUP BY Remitente,Destinatario ;
                         
 /**/                        
 
 /*Cantidad Mensajes Recibidos por Destinatario/Remitente */
SET @Destinatario=2;
SET @Remitente=1;

SELECT d.Usuario as Destinatario,r.Usuario as Remitente, count(d.Usuario) Cantidad_Mensajes_Recibidos
FROM intranet.mensajes m LEFT JOIN intranet.usuarios r ON m.IdRemitente=r.IdUsuarios
						 LEFT JOIN intranet.usuarios d ON m.IdDestinatario=d.IdUsuarios
WHERE m.IdRemitente=@Remitente  /*Este Valor se modifica para filtrar diferentes usuarios Remitentes*/
AND m.IdDestinatario=@Destinatario /*Este Valor se modifica para filtrar diferentes usuarios Destinatarios*/
GROUP BY Destinatario,Remitente ;
                         
 /**/                        
 
 /*Cantidad de Usuarios por Pais*/
SELECT p.Descripcion as Pais,count(distinct u.IdUsuarios) Cant_Usuarios
FROM intranet.usuarios u LEFT JOIN intranet.pais p ON u.IdPais=p.IdPais
GROUP BY Pais;

/*Cantidad Mensajes Recibidos y Leidos por Destinatario/Remitente */

SELECT r.Usuario as Remitente,d.Usuario as Destinatario, count(d.Usuario) Cantidad_Mensajes_Enviados
FROM intranet.mensajes m LEFT JOIN intranet.usuarios r ON m.IdRemitente=r.IdUsuarios
						 LEFT JOIN intranet.usuarios d ON m.IdDestinatario=d.IdUsuarios
WHERE m.MensajeLeido=1
GROUP BY Destinatario,Remitente ;
                         
 /**/     
 
 /*Cantidad Mensajes Enviados Destinatario/Remitente */

SELECT  r.Usuario as Remitente,d.Usuario as Destinatario,m.Fecha as Fecha, count(d.Usuario) Cantidad_Mensajes_Enviados
FROM intranet.mensajes m LEFT JOIN intranet.usuarios r ON m.IdRemitente=r.IdUsuarios
						 LEFT JOIN intranet.usuarios d ON m.IdDestinatario=d.IdUsuarios
GROUP BY Remitente,Destinatario,Fecha ;
                         
 /**/                        