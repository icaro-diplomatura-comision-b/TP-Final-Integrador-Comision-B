const { useColors } = require("debug/src/browser");

module.exports=(sequelize, dataTypes) => {

    const alias = "User";
    const cols={
        id:{
            autoIncrement:true,
            primaryKey: true,
            type:dataTypes.INTEGER,
            //allowNull: false
        },
        username:{
            type:dataTypes.STRING(45),
            //allowNull: false
        },
        firstname:{
            type:dataTypes.STRING(45),
            //allowNull: false
        },
        lastname:{
            type:dataTypes.STRING(45),
            //allowNull: false
        },
        password:{
            type:dataTypes.STRING(100),
            //allowNull: false
        },
        country:{
            type:dataTypes.STRING(45),
            //allowNull: false
        },
        city:{
            type:dataTypes.STRING(45),
            //allowNull: false
        },
        notDeletable:{
            type:dataTypes.TINYINT(1),
            //allowNull: false
        },
        isAdmin:{
            type:dataTypes.TINYINT(1)
        }
    };
    const config={
        tableName:"Users",
        timestamps: false
    }

    const User = sequelize.define(alias, cols, config);

    return User
}