module.exports=(sequelize, dataTypes) => {

    const alias= "Message";
    const cols ={
        messages_id:{
            autoIncrement:true,
            primaryKey: true,
            type:dataTypes.INTEGER,
           // allowNull: false
        },
        destinatario:{
            type:dataTypes.INTEGER,
            //allowNull: false
        },
        asunto:{
            type:dataTypes.STRING(45),
           // allowNull: false
        },
        fecha:{
            type:dataTypes.DATE,
           // allowNull: false
        },
        remitente:{
            type:dataTypes.INTEGER,
            //allowNull: false
        },
        message:{
            type:dataTypes.STRING(150),
           // allowNull: false
        }
    };
    const config={
        tableName: "messages",
        timestamps: false
    }
    const Message = sequelize.define(alias, cols, config);

    return Message
}