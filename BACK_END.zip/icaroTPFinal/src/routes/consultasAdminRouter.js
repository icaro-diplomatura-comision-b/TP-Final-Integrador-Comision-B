var express = require('express');
var router = express.Router();
const consultasAdminController = require('../controller/consultasAdminController')
let authMiddleware = require("../middleware/authMiddleware");
let adminMiddleware = require('../middleware/adminMiddleware')
let { body } = require("express-validator");


/*Mensaje Eliminado*/
router.delete('/adminDeleteM', [adminMiddleware], consultasAdminController.delete)

//Eliminar Usuario
router.delete("/adminDeleteUsers", [adminMiddleware], consultasAdminController.deleteUser)

module.exports = router;