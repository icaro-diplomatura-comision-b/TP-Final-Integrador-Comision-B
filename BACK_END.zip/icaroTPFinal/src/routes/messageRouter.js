var express = require('express');
var router = express.Router();
const messageController = require('../controller/messageController')
let authMiddleware = require("../middleware/authMiddleware");
let { body } = require("express-validator");


let validationNewMessage = [
    body('destinatario').notEmpty().withMessage("Debes de ingresar un destinatario"),
    body('asunto').isLength({ min: 1, max:45 }).withMessage('Debes ingresar asunto de tu msj'),
    body('message').isLength({ min: 25, max:150 }).withMessage('Debes ingresar un mensaje menor a 150 caracteres'),
]


/* Mensajes recibidos*/
router.get('/users/:username/messages/inbox', [authMiddleware], messageController.recibidos);

/*Mensajes Enviados*/
router.get('/users/:username/messages/sent', [authMiddleware], messageController.enviados);

/*Mensaje Nuevos*/
let newMessageMiddleware = validationNewMessage
newMessageMiddleware.push(authMiddleware)
router.post('/users/:username/messages', newMessageMiddleware, messageController.newMessage)

/*Mensaje Eliminado*/
router.delete('/users/:username/messageId', [authMiddleware], messageController.delete)

module.exports = router;