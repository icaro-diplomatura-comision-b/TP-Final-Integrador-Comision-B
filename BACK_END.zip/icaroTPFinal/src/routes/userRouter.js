var express = require('express');
var router = express.Router();
const userController = require ('../controller/userController')
let { body } = require("express-validator");
let authMiddleware = require("../middleware/authMiddleware");

let validationRegister = [
    body('username').notEmpty().withMessage("Debes de ingresar un usuario"), 
    body('password').notEmpty().withMessage('Debes ingresar una contraseña'),
    body('firstname').notEmpty().withMessage("Debes de ingresar un nombre"),
    body('lastname').notEmpty().withMessage("Debes de ingresar un apellido"),
    body('city').notEmpty().withMessage("Debes de ingresar una ciudad"),
    body('country').notEmpty().withMessage("Debes de ingresar un pais"),
]

let validationLogin = [
    body('username').notEmpty().withMessage("Debes de ingresar un usuario"),
    body('password').notEmpty().withMessage('Debes ingresar una contraseña'),
]


//Todos los usuarios Registrados
router.get('/users', [authMiddleware], userController.showUsers);

//Mostrar formulario para crear Usuario
//router.get('/users', userController.form)
router.post('/users', validationRegister, userController.register);

//login
router.post('/login', validationLogin, userController.login);

//logout
router.get(`/logout`, userController.logout);

module.exports = router;