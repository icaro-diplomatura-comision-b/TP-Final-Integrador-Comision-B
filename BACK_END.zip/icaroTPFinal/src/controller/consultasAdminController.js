const db= require("../databases/models")

const consultasAdminController ={
    //Eliminar mensajes
    delete: (req,res) =>{
        console.log("hola")
        if (!req.session.userLogged.isAdmin) {
            res.send({"mensaje": "No podes eliminar mensajes ajenos, debes ser el  administrador"})
            return
        }
        db.Message.destroy({
            where: {
                messages_id: req.body.message_id
            }
        }).then((message) =>{
            console.log("aca")
                res.send({"Mensaje":" Mensaje Eliminado"})
            }).catch((e) => {
                console.log("ACA",e)
                res.send({ "error": e})
            })
    },
    //Eliminar Usuario
    deleteUser:(req,res) =>{
    console.log("ACA")
        if (!req.session.userLogged.isAdmin) {
            res.send({"mensaje": "No podes eliminar mensajes ajenos, debes ser el  administrador"})
            return
        } 
        console.log("HOLA")
        db.User.destroy({
            where:{
                id: req.body.id
            }
        }).then((user) =>{
            console.log(user)
            res.send({"User": "Usuario Eliminado"})
        }).catch((e) =>{
            console.log(e)
            res.send("eror", e)
        })
    }
}


module.exports = consultasAdminController