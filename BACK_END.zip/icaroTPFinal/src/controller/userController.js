const res = require('express/lib/response')
const db = require('../databases/models')

const { validationResult } = require('express-validator');
const bcrypt = require('bcryptjs');


const userController={
    showUsers: (req,res) =>{
        db.User.findAll({
            attributes: {exclude: ['password', 'notDeletable']}
        }).then( (userList) => {
            res.send(userList)
        }).catch(e => {
           res.send({
               message: "Error en busqueda",
               error: e
           })
       })
    },
    register: (req,res) =>{

        let errors = validationResult(req);

        if (!errors.isEmpty()) { 
            res.send(errors)
            return
        }

        try{
            db.User.create({
                username: req.body.username,
                firstname: req.body.firstname,
                lastname: req.body.lastname,
                password: bcrypt.hashSync(req.body.password, 10),
                country: req.body.country,
                city:req.body.city,
                notDeletable: true
            }).then((newUser) => {
                res.send({
                    "mensaje": "Usuario creado con exito",
                    "usuario": newUser.toJSON()
                })
            })
        } catch(e){
            res.send({
                "mensaje": "No se pudo crear el usuario",
                "error": e
            })
        }    
    },

    login: (req,res) =>{
        // Chequear errores primero
        let errors = validationResult(req);
        if (!errors.isEmpty()) { 
            res.send(errors)
            return
        }

        db.User.findOne({
            where: {
                username: req.body.username
            }
        }).then((result) => {
            if (!result) {
                res.send("El usuario no existe")
                return
            }

            let isPasswordValid = bcrypt.compareSync(req.body.password, result.password);
            if (isPasswordValid) {
                req.session.userLogged = result;
                res.send({
                    "mensaje": "Ingreso aceptado"
                })
                return
            }

            res.send("Las credenciales no son validas")
        })
    },

    logout: (req, res) => {
        req.session.destroy();
        res.send({
            mensaje: "Se cerro la sesion con exito."
        })
    },
}

module.exports= userController