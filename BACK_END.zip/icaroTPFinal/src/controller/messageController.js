//const { Association } = require("sequelize/types")
const db= require ("../databases/models")
const { validationResult } = require('express-validator');

const messageController={
    recibidos: (req,res) =>{
        if (req.params.username != req.session.userLogged.username) {
            res.send({"mensaje": "No podes ver mensajes ajenos"})
            return
        }
        
        db.Message.findAll({where:{destinatario: req.session.userLogged.id}})
            .then((messages) =>{
                res.send(messages)
            }).catch((e) => {
                res.send({"mensaje": "Error obteniendo los msj", "error": e})
            })
    },
    enviados: (req,res) =>{
        if (req.params.username != req.session.userLogged.username) {
            res.send({"mensaje": "No podes ver mensajes enviados ajenos"})
            return
        }
        
        db.Message.findAll({where:{remitente: req.session.userLogged.id}})
            .then((messages) =>{
                res.send(messages)
            }).catch((e) => {
                res.send({"mensaje": "Error obteniendo los msj", "error": e})
            })
    },
    newMessage: async (req,res) =>{

        // Chequear errores primero
        let errors = validationResult(req);
        if (!errors.isEmpty()) { 
            res.send(errors)
            return
        }

        db.User.findOne({where: {id: req.body.destinatario}}).then((destUser) => {
            if (!destUser) {
                res.send({
                    "mensaje": "No podemos enviar el mensaje porque no existe el destinatario"
                })
                return
            }

            db.Message.create({
                destinatario: destUser.id,
                asunto: req.body.asunto,
                fecha:new Date().toLocaleString(),
                remitente: req.session.userLogged.id,
                message: req.body.message
            })
    
            res.send({
                mensaje: "Mensaje enviado con exito"
            })
        }).catch((err) => {
            console.log("no",err)
            res.send("Destinatario inexistente")
        })
    },
    delete: (req,res) =>{
        if (req.params.username != req.session.userLogged.username) {
            res.send({"mensaje": "No podes eliminar mensajes ajenos"})
            return
        } 
        db.Message.destroy({
            where: {
                messages_id: req.body.message_id
            }
        }).then((message) =>{
            res.send({mensaje:" Mensaje Eliminado"})
        }).catch((e) => {
             res.send({ "error": e})
        })
    }
}

module.exports= messageController