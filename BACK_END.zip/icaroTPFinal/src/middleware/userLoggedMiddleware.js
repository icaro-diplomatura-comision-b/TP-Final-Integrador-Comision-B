const db = require ('../databases/models')

module.exports = async function userLoggedMiddleware(req,res,next){
    
    try{
    
        res.locals.isLogged = false;

        let emailCookie = req.cookies.userEmail;

        let userFromCookie;

        if(emailCookie){
            userFromCookie = await db.User.findOne({
                where: {
                    email: emailCookie
                }
            })
        }

        if(userFromCookie) {
            req.session.userLogged = userFromCookie;
        }

// en esta parte estamos compartiendo con la variable del front, locals, la información que tenemos en session del lado del back.
        if(req.session.userLogged){
            res.locals.isLogged = true;
            res.locals.userLogged = req.session.userLogged;
        }        
        
        next()
        
    } catch (e) { res.send("soy el catch") };

}

