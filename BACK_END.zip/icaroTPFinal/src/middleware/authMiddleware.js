function authMiddleware(req,res,next){
    if(!req.session.userLogged) {
        // return res.redirect('/api/login/')
        return res.send({"mensaje": "Debes iniciar sesion primero"})
    }

    next();

}

module.exports = authMiddleware;