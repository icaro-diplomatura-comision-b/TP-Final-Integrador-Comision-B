function adminMiddleware(req,res,next){
    console.log("Checking adminMiddleware")
    if (!req.session.userLogged) {
        console.log("no logged in, error")
        return res.send({"mensaje": "Debes estar logueado"})
    }
    if(!req.session.userLogged.isAdmin) {
        console.log("no isAdmin, error")
        return res.send({"mensaje": "Debes ser administrador"})
    }
    console.log("is admin next()")
    next();

}

module.exports = adminMiddleware;